GPCR Selectivity Atlas structure bundle: A6PX-P061-0120
Candidate ligand: ligand/A6PX-P061-0120.sdf
Audited MM/GBSA complex PDB files: 2
PDB files are computational receptor-ligand complexes, not experimental structures.
