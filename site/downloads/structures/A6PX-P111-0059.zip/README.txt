GPCR Selectivity Atlas structure bundle: A6PX-P111-0059
Candidate ligand: ligand/A6PX-P111-0059.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
