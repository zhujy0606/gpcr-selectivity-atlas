GPCR Selectivity Atlas structure bundle: A6PX-P013-0097
Candidate ligand: ligand/A6PX-P013-0097.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
