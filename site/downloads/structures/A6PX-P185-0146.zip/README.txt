GPCR Selectivity Atlas structure bundle: A6PX-P185-0146
Candidate ligand: ligand/A6PX-P185-0146.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
