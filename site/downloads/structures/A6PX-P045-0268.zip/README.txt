GPCR Selectivity Atlas structure bundle: A6PX-P045-0268
Candidate ligand: ligand/A6PX-P045-0268.sdf
Audited MM/GBSA complex PDB files: 2
PDB files are computational receptor-ligand complexes, not experimental structures.
