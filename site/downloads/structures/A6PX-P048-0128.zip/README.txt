GPCR Selectivity Atlas structure bundle: A6PX-P048-0128
Candidate ligand: ligand/A6PX-P048-0128.sdf
Audited MM/GBSA complex PDB files: 3
PDB files are computational receptor-ligand complexes, not experimental structures.
