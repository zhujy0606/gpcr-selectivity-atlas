GPCR Selectivity Atlas structure bundle: A6PX-P182-0047
Candidate ligand: ligand/A6PX-P182-0047.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
