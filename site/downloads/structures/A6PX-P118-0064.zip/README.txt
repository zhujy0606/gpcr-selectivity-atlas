GPCR Selectivity Atlas structure bundle: A6PX-P118-0064
Candidate ligand: ligand/A6PX-P118-0064.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
