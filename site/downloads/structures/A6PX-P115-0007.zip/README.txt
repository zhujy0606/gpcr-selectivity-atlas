GPCR Selectivity Atlas structure bundle: A6PX-P115-0007
Candidate ligand: ligand/A6PX-P115-0007.sdf
Audited MM/GBSA complex PDB files: 3
PDB files are computational receptor-ligand complexes, not experimental structures.
