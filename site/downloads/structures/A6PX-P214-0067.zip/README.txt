GPCR Selectivity Atlas structure bundle: A6PX-P214-0067
Candidate ligand: ligand/A6PX-P214-0067.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
