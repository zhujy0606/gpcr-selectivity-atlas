GPCR Selectivity Atlas structure bundle: A6PX-P155-0242
Candidate ligand: ligand/A6PX-P155-0242.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
