GPCR Selectivity Atlas structure bundle: A6PX-P161-0184
Candidate ligand: ligand/A6PX-P161-0184.sdf
Audited MM/GBSA complex PDB files: 2
PDB files are computational receptor-ligand complexes, not experimental structures.
