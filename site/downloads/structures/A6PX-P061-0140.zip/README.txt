GPCR Selectivity Atlas structure bundle: A6PX-P061-0140
Candidate ligand: ligand/A6PX-P061-0140.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
