GPCR Selectivity Atlas structure bundle: A6PX-P044-0038
Candidate ligand: ligand/A6PX-P044-0038.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
