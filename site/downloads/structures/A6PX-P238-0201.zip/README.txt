GPCR Selectivity Atlas structure bundle: A6PX-P238-0201
Candidate ligand: ligand/A6PX-P238-0201.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
