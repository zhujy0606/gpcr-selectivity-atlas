GPCR Selectivity Atlas structure bundle: A6PX-P045-0197
Candidate ligand: ligand/A6PX-P045-0197.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
