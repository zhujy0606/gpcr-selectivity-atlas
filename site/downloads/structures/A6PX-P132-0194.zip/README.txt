GPCR Selectivity Atlas structure bundle: A6PX-P132-0194
Candidate ligand: ligand/A6PX-P132-0194.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
