GPCR Selectivity Atlas structure bundle: A6PX-P049-0222
Candidate ligand: ligand/A6PX-P049-0222.sdf
Audited MM/GBSA complex PDB files: 2
PDB files are computational receptor-ligand complexes, not experimental structures.
