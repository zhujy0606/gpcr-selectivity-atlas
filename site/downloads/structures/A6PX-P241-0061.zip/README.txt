GPCR Selectivity Atlas structure bundle: A6PX-P241-0061
Candidate ligand: ligand/A6PX-P241-0061.sdf
Audited MM/GBSA complex PDB files: 3
PDB files are computational receptor-ligand complexes, not experimental structures.
