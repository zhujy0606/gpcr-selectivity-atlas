GPCR Selectivity Atlas structure bundle: A6PX-P051-0034
Candidate ligand: ligand/A6PX-P051-0034.sdf
Audited MM/GBSA complex PDB files: 0
PDB files are computational receptor-ligand complexes, not experimental structures.
