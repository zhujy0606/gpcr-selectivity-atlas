GPCR Selectivity Atlas structure bundle: A6PX-P136-0250
Candidate ligand: ligand/A6PX-P136-0250.sdf
Audited MM/GBSA complex PDB files: 4
PDB files are computational receptor-ligand complexes, not experimental structures.
