GPCR Selectivity Atlas structure bundle: A6PX-P013-0103
Candidate ligand: ligand/A6PX-P013-0103.sdf
Audited MM/GBSA complex PDB files: 2
PDB files are computational receptor-ligand complexes, not experimental structures.
